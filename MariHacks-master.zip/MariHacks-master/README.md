# MariHacks

Developped at the first ever MariHacks, "Silent Voice", is an English to American Sign Language speech-to-video transator. In Canada, 350,000 individuals are legally deaf, while over 3.2 million are hard of hearing. Nevertheless little is done in terms of services to accomodate these people and integrate them within a communnity. "Silent Voice" seeks to bridge the linguistic gap by providing accesssible and efficient translation that eases communication.
